package com.example.quizapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RadioGroup q1Group, q2Group, q3Group;
    Button submitButton;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        q1Group = findViewById(R.id.q1_group);
        q2Group = findViewById(R.id.q2_group);
        q3Group = findViewById(R.id.q3_group);
        submitButton = findViewById(R.id.submit_button);
        resultText = findViewById(R.id.result_text);

        submitButton.setOnClickListener(v -> {
            int score = 0;
            if (q1Group.getCheckedRadioButtonId() == R.id.q1_opt_a) score++;
            if (q2Group.getCheckedRadioButtonId() == R.id.q2_opt_b) score++;
            if (q3Group.getCheckedRadioButtonId() == R.id.q3_opt_c) score++;

            resultText.setText("Your Score: " + score + " / 3");
            Toast.makeText(this, "Submitted", Toast.LENGTH_SHORT).show();
        });
    }
}
